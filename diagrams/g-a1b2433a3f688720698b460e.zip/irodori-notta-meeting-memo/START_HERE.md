# Codexセットアップ入口

このファイルは、ダウンロードされたSkill ZIPを受け取ったCodexが読むための入口です。利用者へターミナル操作やZIPの展開を求めず、Codex自身がセットアップを進めてください。

## 目的

`irodori-notta-meeting-memo` Skillを安全に配置し、Notta CLI・認証・同梱された確認済み出力テンプレートの準備状態と完全性を確認する。録画、Bot参加、常時監視、外部送信、共有、公開は開始しない。

## セットアップ

1. ZIPを一意の一時フォルダへ展開する。Downloads直下へファイルをばらまかない。
2. 展開物に次があることを確認する。
   - `irodori-notta-meeting-memo/SKILL.md`
   - `irodori-notta-meeting-memo/references/phase-checks.md`
   - `irodori-notta-meeting-memo/assets/templates/irodori-current/template.md`
   - `irodori-notta-meeting-memo/scripts/install_skill.sh`
   - `irodori-notta-meeting-memo/scripts/preflight.sh`
3. 展開したSkillフォルダを作業ディレクトリにし、Codex自身が次を実行する。

```bash
zsh scripts/install_skill.sh
```

4. インストール済みSkillの `scripts/preflight.sh` をCodex自身が1回だけ実行し、結果を利用者へ伝える。

## 上書きルール

- 対象は `$HOME/.agents/skills/irodori-notta-meeting-memo`。
- 未導入なら配置する。
- 同一内容なら何も変更しない。
- 既存内容が異なる場合は上書きせず、差異があることを利用者へ報告して止める。

## 本人操作が必要な場合

- Notta CLIの導入が必要なら、パッケージ名と目的を一文で説明し、インストールしてよいか確認する。許可後のコマンドはCodexが実行する。
- Notta認証が必要なら、Codexが `notta auth setup` を開始し、ログイン済みChrome拡張でNotta公式OAuth画面を開く。利用者はログイン・同意だけ行う。
- 認証完了後はCodexが接続を再確認する。token、Cookie、認証ファイルの内容は読まない。

## Salesforceを使う場合の任意診断

利用者がSalesforceにも面談記録を残したい場合だけ、書き込み前に次を読み取りで確認する。

1. このCodexにSalesforce用の既存MCP、コネクタ、API helper、Salesforce CLIがあるか。
2. Salesforce公式Hosted MCP Serverを使える場合は、削除権限を含まない `SObject Mutations` を第一候補にする。
3. Hosted MCPが使えなければ、Salesforce公式APIまたはSalesforce CLIを次候補にする。
4. 公式連携が使えず、ログイン済みChrome拡張でSalesforce画面を確認できる場合だけ、画面操作を最終候補として報告する。
5. `現在利用可能 / Salesforce管理者の有効化が必要 / 本人のOAuth操作が必要 / 未確認` を分け、いちばん簡単で安全な導入案を返す。

この診断では、MCPやアプリの追加、Salesforce設定変更、ログイン、顧客データの作成・更新・削除を行わない。実際の書き込みは、接続経路、対象顧客、記録先オブジェクトと項目を別途確認した後に行う。

## 完了報告

次を短く報告する。

- Skillの配置結果：新規／同一で変更なし／既存差異で停止
- Node.js、npm、Notta CLI、Notta認証、現在版テンプレートpackの完全性
- 過去テンプレート構造と、本人限定の過去実例が同梱されているか
- 商談フェーズの `OI / FF / PC / N` 個別チェック規則と、箇条書きの次回アクション規則が同梱されているか
- 本人限定の過去実例がある場合、2件の実ファイルと `checksums.sha256` の照合が `verified` か
- 利用者に必要な次の操作がある場合は、その1操作だけ
- Salesforceを使う場合は、利用可能な接続経路と必要な次の1操作
- 外部送信・共有を行っていないこと

Skillが現在のタスクで認識されない場合だけ、Codexの新しいタスクを開いて、HTMLの通常起動文を送るよう案内する。

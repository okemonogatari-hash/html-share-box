#!/usr/bin/env python3

import importlib.util
import json
import tempfile
import unittest
from pathlib import Path


MODULE_PATH = Path(__file__).with_name("normalize_notta.py")
SPEC = importlib.util.spec_from_file_location("normalize_notta", MODULE_PATH)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(MODULE)


class NormalizeNottaTests(unittest.TestCase):
    def test_verified_cli_schema_preserves_speaker_and_time(self):
        payload = {
            "error_code": 0,
            "data": {
                "content": [
                    {
                        "attr": {
                            "speaker_name": "話者A",
                            "start_time": 2.06,
                            "stop_time": 14.64,
                        },
                        "text": "確認しました。",
                    }
                ]
            },
        }
        body = MODULE.normalize(payload)
        self.assertIn("00:00:02.060-00:00:14.640｜話者A", body)
        self.assertIn("確認しました。", body)

    def test_unverified_flat_schema_fails_closed(self):
        payload = {
            "error_code": 0,
            "data": {"content": [{"speaker_name": "A", "start_time": 2, "text": "確認"}]},
        }
        with self.assertRaisesRegex(ValueError, "schema is unverified"):
            MODULE.normalize(payload)

    def test_provider_error_fails_closed(self):
        with self.assertRaisesRegex(ValueError, "error_code=110002"):
            MODULE.normalize({"error_code": 110002, "data": {}})

    def test_render_records_source_sha(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            source = Path(temp_dir) / "sample.json"
            source.write_text(json.dumps({"error_code": 0}), encoding="utf-8")
            rendered = MODULE.render(source, "本文")
            self.assertIn(MODULE.sha256(source), rendered)
            self.assertIn("transcript_verified", rendered)


if __name__ == "__main__":
    unittest.main()


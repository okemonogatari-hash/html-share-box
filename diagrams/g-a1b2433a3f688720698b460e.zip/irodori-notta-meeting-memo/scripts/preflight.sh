#!/bin/zsh
set -u

script_dir="${0:A:h}"
skill_dir="${script_dir:h}"
profile_path="${skill_dir}/assets/templates/irodori-current/profile.yaml"
template_path="${skill_dir}/assets/templates/irodori-current/template.md"
historical_reference_path="${skill_dir}/references/historical-template-shape.md"
private_context_dir="${skill_dir}/references/client-private"
private_manifest_path="${private_context_dir}/manifest.yaml"
private_checksums_path="${private_context_dir}/checksums.sha256"

has_command() {
  command -v "$1" >/dev/null 2>&1
}

if has_command node; then
  echo "node=present"
  node_state="present"
else
  echo "node=missing"
  node_state="missing"
fi

if has_command npm; then
  echo "npm=present"
  npm_state="present"
else
  echo "npm=missing"
  npm_state="missing"
fi

if has_command notta; then
  echo "notta_cli=present"
  notta_version="$(notta --version 2>/dev/null | head -n 1)"
  if [[ -n "${notta_version}" ]]; then
    echo "notta_version=${notta_version}"
  else
    echo "notta_version=detected"
  fi

  if notta list --page 1 --page_size 1 >/dev/null 2>&1; then
    echo "notta_auth=ready"
    auth_state="ready"
  else
    echo "notta_auth=required_or_failed"
    auth_state="required_or_failed"
  fi
  notta_state="present"
else
  echo "notta_cli=missing"
  echo "notta_version=unavailable"
  echo "notta_auth=unavailable"
  notta_state="missing"
  auth_state="unavailable"
fi

if [[ -f "${profile_path}" ]] && grep -q '^status: current$' "${profile_path}"; then
  expected_template_sha="$(sed -n 's/^source_sha256: "\([0-9a-f][0-9a-f]*\)"$/\1/p' "${profile_path}" | head -n 1)"
  if [[ -f "${template_path}" && -n "${expected_template_sha}" ]]; then
    actual_template_sha="$(shasum -a 256 "${template_path}" | awk '{print $1}')"
    if [[ "${actual_template_sha}" == "${expected_template_sha}" ]]; then
      echo "template=current"
      echo "template_integrity=verified"
      template_state="current"
    else
      echo "template=invalid"
      echo "template_integrity=sha_mismatch"
      template_state="invalid"
    fi
  else
    echo "template=invalid"
    echo "template_integrity=missing_file_or_hash"
    template_state="invalid"
  fi
else
  echo "template=pending"
  echo "template_integrity=not_applicable"
  template_state="pending"
fi

if [[ -f "${historical_reference_path}" ]]; then
  echo "historical_template_reference=available"
else
  echo "historical_template_reference=missing"
fi

if [[ -f "${private_manifest_path}" && -f "${private_checksums_path}" ]]; then
  private_docx_count="$(find "${private_context_dir}/historical_examples" -type f -name '*.docx' 2>/dev/null | wc -l | tr -d ' ')"
  if [[ "${private_docx_count}" == "2" ]] && (cd "${private_context_dir}" && shasum -a 256 -c checksums.sha256 >/dev/null 2>&1); then
    echo "client_private_examples=available"
    echo "client_private_examples_integrity=verified"
  else
    echo "client_private_examples=invalid"
    echo "client_private_examples_integrity=failed"
  fi
else
  echo "client_private_examples=not_included"
  echo "client_private_examples_integrity=not_applicable"
fi

if [[ "${node_state}" != "present" || "${npm_state}" != "present" ]]; then
  echo "overall=node_or_npm_missing"
elif [[ "${notta_state}" != "present" ]]; then
  echo "overall=notta_cli_missing"
elif [[ "${auth_state}" != "ready" ]]; then
  echo "overall=auth_required_or_failed"
elif [[ "${template_state}" == "invalid" ]]; then
  echo "overall=template_invalid"
elif [[ "${template_state}" != "current" ]]; then
  echo "overall=template_pending"
else
  echo "overall=ready"
fi

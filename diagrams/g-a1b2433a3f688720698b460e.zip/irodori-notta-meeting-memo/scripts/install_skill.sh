#!/bin/zsh
set -euo pipefail

script_dir="${0:A:h}"
source_dir="${script_dir:h}"
target_root="${HOME}/.agents/skills"
target_dir="${target_root}/irodori-notta-meeting-memo"

if [[ ! -f "${source_dir}/SKILL.md" ]]; then
  echo "install_result=invalid_package"
  exit 1
fi

mkdir -p "${target_root}"

if [[ -e "${target_dir}" ]]; then
  if diff -qr "${source_dir}" "${target_dir}" >/dev/null 2>&1; then
    echo "install_result=already_current"
    echo "installed_path=${target_dir}"
    exit 0
  fi
  echo "install_result=existing_differs"
  echo "installed_path=${target_dir}"
  exit 2
fi

if command -v ditto >/dev/null 2>&1; then
  ditto "${source_dir}" "${target_dir}"
else
  cp -R "${source_dir}" "${target_dir}"
fi

if [[ ! -f "${target_dir}/SKILL.md" ]]; then
  echo "install_result=verification_failed"
  exit 1
fi

echo "install_result=installed"
echo "installed_path=${target_dir}"

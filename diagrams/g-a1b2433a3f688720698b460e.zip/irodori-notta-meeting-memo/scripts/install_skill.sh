#!/bin/sh
# Compatibility entry; Windows users use the Python file directly.
exec python3 "$(dirname "$0")/install_skill.py" "$@"

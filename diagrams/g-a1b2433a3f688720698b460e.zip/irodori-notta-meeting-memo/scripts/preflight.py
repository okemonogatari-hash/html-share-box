#!/usr/bin/env python3
"""Read local integrity by default. Notta connection is opt-in and bounded."""
import argparse, hashlib, json, re, shutil, subprocess
from pathlib import Path

def check(root, check_notta=False):
    profile=root/"assets/templates/irodori-current/profile.yaml"
    template=profile.with_name("template.md")
    txt=profile.read_text(encoding="utf-8") if profile.exists() else ""
    match=re.search(r'^source_sha256: "([a-f0-9]{64})"$',txt,re.M)
    ok=bool(re.search(r'^status: current$',txt,re.M) and match and template.exists()
            and hashlib.sha256(template.read_bytes()).hexdigest()==match[1])
    report={"template_integrity":"verified" if ok else "invalid",
            "node":bool(shutil.which("node")),"npm":bool(shutil.which("npm")),
            "notta_cli":bool(shutil.which("notta")),"notta_auth":"not_checked"}
    private=root/"references/client-private"
    if private.exists():
        hashes=private/"checksums.sha256"
        valid=hashes.exists()
        if valid:
            for line in hashes.read_text(encoding="utf-8").splitlines():
                if not line.strip(): continue
                digest, name=line.split(maxsplit=1)
                name=name.lstrip("*")
                path=(private/name).resolve()
                if private.resolve() not in path.parents or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
                    valid=False; break
        report["client_private_examples_integrity"]="verified" if valid else "invalid"
    else: report["client_private_examples_integrity"]="not_included"
    if check_notta and report["notta_cli"]:
        try:
            # .cmd requires the Windows shell; command and numeric arguments are fixed.
            result=subprocess.run([shutil.which("notta"),"list","--page","1","--page_size","1"],
                stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=30,
                shell=__import__("os").name=="nt")
            report["notta_auth"]="ready" if result.returncode==0 else "required_or_failed"
        except (subprocess.TimeoutExpired,OSError): report["notta_auth"]="connection_unconfirmed"
    report["attachment_draft_ready"]=ok
    return report
if __name__=="__main__":
    ap=argparse.ArgumentParser(); ap.add_argument("--check-notta",action="store_true")
    print(json.dumps(check(Path(__file__).resolve().parents[1],ap.parse_args().check_notta),ensure_ascii=False))

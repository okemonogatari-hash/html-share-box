#!/usr/bin/env python3
"""Normalize official Notta CLI JSON into evidence-preserving Markdown."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
from typing import Any


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def clean(value: Any) -> str:
    if value is None:
        return ""
    return " ".join(str(value).split())


def format_seconds(value: Any) -> str:
    if not isinstance(value, (int, float)):
        raise ValueError("Notta start_time must be numeric seconds in the verified CLI schema.")
    total_ms = round(float(value) * 1000)
    hours, remainder = divmod(total_ms, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    seconds, milliseconds = divmod(remainder, 1000)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}.{milliseconds:03d}"


def normalize(payload: dict[str, Any]) -> str:
    if payload.get("error_code") not in (None, 0):
        raise ValueError(f"Notta returned error_code={payload.get('error_code')}")
    data = payload.get("data")
    if not isinstance(data, dict):
        raise ValueError("Notta JSON has no data object.")
    content = data.get("content")
    if not isinstance(content, list) or not content:
        raise ValueError("Notta JSON has no transcript content.")

    lines: list[str] = []
    for index, item in enumerate(content, start=1):
        if not isinstance(item, dict):
            continue
        attr = item.get("attr")
        if not isinstance(attr, dict):
            raise ValueError(f"Segment {index} has no attr object; schema is unverified.")
        body = clean(item.get("text"))
        if not body:
            continue
        speaker = clean(attr.get("speaker_name")) or "話者未確認"
        start = format_seconds(attr.get("start_time"))
        stop = format_seconds(attr.get("stop_time"))
        lines.append(f"### {start}-{stop}｜{speaker}\n\n{body}")
    if not lines:
        raise ValueError("Notta JSON contained no non-empty transcript segments.")
    return "\n\n".join(lines)


def render(source: Path, body: str) -> str:
    acquired_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    return (
        "---\n"
        f'source_path: "{source.resolve()}"\n'
        f'source_sha256: "{sha256(source)}"\n'
        'source_provider: "notta"\n'
        'source_schema: "notta-cli-data-content-attr-seconds"\n'
        f'acquired_at: "{acquired_at}"\n'
        "normalization_status: transcript_verified\n"
        "---\n\n"
        "# Notta文字起こし（正規化原液）\n\n"
        f"{body.rstrip()}\n"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if not args.input.is_file():
        parser.error(f"Input file not found: {args.input}")
    try:
        payload = json.loads(args.input.read_text(encoding="utf-8-sig"))
        if not isinstance(payload, dict):
            raise ValueError("Expected a JSON object.")
        result = render(args.input, normalize(payload))
    except (json.JSONDecodeError, UnicodeDecodeError, ValueError) as exc:
        parser.error(str(exc))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(result, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


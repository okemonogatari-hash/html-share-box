#!/usr/bin/env python3
"""Install this skill; explicit --update keeps a complete backup outside discovery."""
import argparse, hashlib, json, os, shutil, tempfile
from datetime import datetime, timezone
from pathlib import Path
NAME = "irodori-notta-meeting-memo"
def tree(root):
    result = {}
    for f in sorted(root.rglob("*")):
        if f.is_symlink():
            raise ValueError("Symbolic links are not supported")
        if f.is_file() and "__pycache__" not in f.parts and f.suffix != ".pyc":
            result[f.relative_to(root).as_posix()] = hashlib.sha256(f.read_bytes()).hexdigest()
    return result

def install(source, target_root, update=False):
    source, target_root = source.resolve(), target_root.expanduser().absolute()
    if target_root.is_symlink(): raise ValueError("Symlink destination rejected")
    target_root = target_root.resolve()
    target = target_root / NAME
    if source == target.resolve():
        return {"result":"already_current", "path":str(target)}
    if not (source / "SKILL.md").is_file(): raise ValueError("Missing SKILL.md")
    expected = tree(source)
    if target.is_symlink(): raise ValueError("Symlink target rejected")
    if target.exists():
        if all(tree(target).get(k) == v for k,v in expected.items()):
            return {"result":"already_current", "path":str(target)}
        if not update:
            return {"result":"existing_differs", "path":str(target)}
    target_root.mkdir(parents=True, exist_ok=True)
    backup = None
    with tempfile.TemporaryDirectory(prefix="memo-stage-", dir=target_root.parent) as tmp:
        staged = Path(tmp) / NAME
        shutil.copytree(source, staged, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        if target.exists():
            # Keep local additions, including private examples, without publishing them.
            for name in tree(target):
                if name not in expected:
                    dest = staged / name
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(target / name, dest)
        staged_hashes = tree(staged)
        if any(staged_hashes.get(k) != v for k,v in expected.items()):
            raise ValueError("Staging verification failed")
        if target.exists():
            backup_root = target_root.parent / "skill-backups"
            backup_root.mkdir(exist_ok=True)
            backup = Path(tempfile.mkdtemp(prefix=NAME+"-", dir=backup_root)) / NAME
            shutil.copytree(target, backup)
            if tree(backup) != tree(target): raise ValueError("Backup verification failed")
            # Rename preserves the old directory until replacement succeeds.
            old = Path(tmp) / "previous"
            target.rename(old)
            try:
                staged.rename(target)
            except BaseException:
                old.rename(target)
                raise
        else:
            staged.rename(target)
        if tree(target) != staged_hashes: raise ValueError("Installed verification failed")
    return {"result":"updated" if backup else "installed", "path":str(target),
            "backup":str(backup) if backup else None, "files_verified":len(staged_hashes)}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--target-root", type=Path, default=Path.home()/".agents"/"skills")
    ap.add_argument("--update", action="store_true")
    args=ap.parse_args()
    result=install(Path(__file__).resolve().parents[1], args.target_root, args.update)
    print(json.dumps(result,ensure_ascii=False))
    return 2 if result["result"]=="existing_differs" else 0
if __name__=="__main__": raise SystemExit(main())

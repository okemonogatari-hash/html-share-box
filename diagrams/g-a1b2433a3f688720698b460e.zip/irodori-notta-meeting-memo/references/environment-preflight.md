# 環境事前診断

利用者へターミナル操作やコマンドのコピーを求めない。Codexがシェルを使って、必要な環境を自分で確認する。

## 最初に実行する読取診断

Skillのルートを作業ディレクトリにし、次を1回だけ実行する。

```bash
zsh scripts/preflight.sh
```

診断スクリプトはNode.js、npm、Notta CLI、Notta認証、会社テンプレートの状態だけを返す。Nottaの会議一覧や本文、認証情報は表示せず、ファイルも変更しない。

内部で確認する項目は次のとおり。

```bash
command -v node
command -v npm
command -v notta
notta --version
notta list --page 1 --page_size 1 >/dev/null
```

## 状態ごとの扱い

### ready

Node.js、npm、Notta CLI、Notta認証、現行会社テンプレートが利用可能。対象会議の照合へ進む。

### template_pending

取得環境は使えるが、会社テンプレートが未確認。本番用の面談メモは作らず、現行原本の提供を依頼して止める。ユーザーが明示的にデモを指定した場合だけデモ用テンプレートを使う。

### notta_cli_missing

npmが利用できる場合、公式パッケージ `@notta-labs/notta-cli@1.0.7` を導入する必要があることを一文で説明し、インストールしてよいか1回だけ確認する。

ユーザーが許可したら、Codex自身が次を実行する。

```bash
npm install -g @notta-labs/notta-cli@1.0.7
notta --version
```

利用者へコマンドの貼り付けを求めない。許可がないままソフトウェアを導入しない。

### node_or_npm_missing

実際に欠けているものをそのまま報告し、Node.js環境のセットアップを提案して止める。未確認の原因やOSを推測しない。セットアップはユーザーの許可後にCodexが行い、完了後に診断をやり直す。

### auth_required_or_failed

`notta list` が成功しなかった状態。未認証だけでなく、一時的な通信失敗やCLI側エラーも含み得るため、この結果だけでOAuthを開始しない。

CodexがNotta公式CLIの安全な読取診断で未認証と確認できた場合だけ `notta auth setup` を開始し、認証プロセスを保持する。原因を区別できない場合は「認証が必要、または接続確認に失敗」と報告し、認証情報を変更せず止める。ログインが必要な画面は、ログイン済みChrome拡張経路でNotta公式OAuth画面を開いて利用者へ引き渡す。

利用者が行うのは、公式画面でのログインと同意だけ。完了の連絡を受けたら、Codexが次を再実行して接続を確認する。

```bash
notta list --page 1 --page_size 1 >/dev/null
```

公式OAuth画面以外でパスワードや認証コードを聞かない。認証ファイル、token、Cookieの中身を表示・保存・成果物化しない。

## 境界

- 事前診断は1回で終わる。バックグラウンド監視やループを残さない。
- ソフトウェア導入前は利用者の許可を取る。
- OAuthの本人操作は利用者へ渡し、Codexが代理同意しない。
- 診断後も、録画、Bot参加、外部共有、送信、公開は開始しない。

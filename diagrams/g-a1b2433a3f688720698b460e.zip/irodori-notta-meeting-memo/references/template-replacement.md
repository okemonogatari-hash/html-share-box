# 現行テンプレートの差し替え

## 現在の状態

このドラフトにはirodoriの現行会社テンプレートを含めていない。`assets/templates/irodori-current/profile.yaml` は `status: pending` であり、本番出力を止めるためのゲートである。

2026年7月の過去実例2件と、当時のテンプレート構造は再発見済みである。[過去テンプレート構造と再発見ルール](historical-template-shape.md)を比較・受入に使う。ただし当時の原本は2024年11月版なので、現行原本の代用にはしない。

## 差し替え手順

1. 現在使っている空テンプレート原本が見当たらない場合、ローカル案件索引と本人のGoogle Driveを読取探索する。それでも現行性を確認できない時だけ、利用者へ原本を依頼する。
2. 原本を上書きせず `assets/templates/irodori-current/` へ保存する。
3. 原本のSHA-256を取得する。
4. 見出し、表、チェック欄、条件分岐、必須／任意を `template.md` へ写す。
5. `profile.yaml` を更新する。

```yaml
template_id: irodori-current
version: "確認した版"
status: current
source_filename: "原本ファイル名"
source_sha256: "原本SHA-256"
verified_at: "YYYY-MM-DD"
verified_by: "確認者"
output_format: docx
unknown_policy: "要確認（文字起こしに明示なし）"
```

6. 匿名の文字起こしで、全項目・チェック欄・条件分岐を検証する。
7. 納品先本人の実際のNotta record 1件で、取得から下書き保存まで受入テストする。

2024年11月版など、現行性を確認できないテンプレートは `current` にしない。

# 現在版テンプレートの管理

## 現在の状態

`assets/templates/irodori-current/template.md` は、2026年7月の顧客入り出力見本と2026年8月27日の修正指示から、個人情報を除いて固定した現在版の出力基準である。`profile.yaml` は `status: current` とする。

元のGoogleドキュメントは空欄原本ではないが、依頼者がその文書を直接示して出力修正を求めたため、実務上の受入基準として扱う。顧客情報と文書IDは公開packへ入れず、本人限定packのmanifestでだけ管理する。

別の空テンプレート原本が届くまで停止する必要はない。より新しい会社様式が明示された場合だけ、以下の差し替え手順を使う。

## 差し替え手順

1. 利用者または担当者が、現在版より新しい会社様式であると明示したファイルを確認する。
2. 原本を上書きせず `assets/templates/irodori-current/` へ保存する。
3. 原本のSHA-256を取得する。
4. 見出し、表、チェック欄、条件分岐、必須／任意を `template.md` へ写す。
5. `profile.yaml` を更新する。

```yaml
template_id: irodori-current
version: "確認した版"
status: current
  source_filename: "匿名化した現在版template.md"
  source_sha256: "template.mdのSHA-256"
verified_at: "YYYY-MM-DD"
verified_by: "確認者"
output_format: docx
unknown_policy: "要確認（文字起こしに明示なし）"
```

6. 匿名の文字起こしで、全項目・チェック欄・条件分岐を検証する。
7. 納品先本人の実際のNotta record 1件で、取得から下書き保存まで受入テストする。

2024年11月版など、現行性を確認できないテンプレートへ戻さない。新様式が明示されない限り、同梱の `accepted-output-2026-08-27-v1` を現在版として使う。

# Notta公式CLIの実機経路

ここにあるコマンドはCodexがシェルで実行する。利用者へターミナル操作や貼り付けを求めない。CLI導入前は許可を取り、OAuthが必要な場合だけ公式画面での本人操作を依頼する。

## 2026-08-24に確認できたこと

Freeプランの実Zoom会議へNotta Botを手動参加させ、公式CLI `@notta-labs/notta-cli` 1.0.7で次を確認した。

- 会議中から `notta list` に `platform: ConferenceAssistant` としてrecordが現れる。
- 会議中は `status: Transcribing`。
- この状態の `notta view` はエラー `110002`。処理中を意味し、失敗ではない。
- Zoom終了後に `status: Transcribed` へ変わると、同じrecord IDから話者名・本文・開始終了時刻を取得できる。
- `data.content[].attr.start_time` と `stop_time` は、Notta画面と照合して秒単位だった。

## 実行順

```bash
notta list --page 1 --page_size 100
notta status RECORD_ID
notta view RECORD_ID
```

対象同一性はrecord ID、会議タイトル、日時、参加者で確認する。タイトルだけで選ばない。

## 初回認証

```bash
notta auth setup
```

ブラウザでNotta公式OAuthへの同意が必要。本人が操作する。認証情報をコピー、表示、納品物へ保存しない。

## 境界

- Notta Botの自動参加設定はこのSkillの外。
- Zoomの録画とNotta文字起こしを同じ成果物とみなさない。
- `status --wait` は、会議終了済みかつ明示依頼がある1件だけ。
- HTML画面や非公開endpointをスクレイピングしない。

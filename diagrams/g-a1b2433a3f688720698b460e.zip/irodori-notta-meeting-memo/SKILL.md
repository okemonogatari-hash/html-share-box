---
name: irodori-notta-meeting-memo
description: Zoom会議をNotta Botで文字起こしした1件を、確認済みの面談メモ出力基準へ根拠どおり整理し、下書きと根拠manifestを作る。ユーザーが明示的に「$irodori-notta-meeting-memo 今日の面談を下書きにして」と起動した時に使う。Nottaの自動参加設定、常時監視、録画、外部送信、共有、正式な顧客記録の確定には使わない。
---

# irodori Notta面談メモ

## ゴール

対象会議を取り違えず、Notta公式CLIで確認できた文字起こし全文を一次根拠に、会社テンプレートと同じ構造の「下書き」を作る。会話にない事実は補わない。

## 安全ゲート

- このSkillは明示起動だけで動く。雑談やNottaへの言及だけでは開始しない。
- 録画、Notta Bot参加、Zoom設定、自動監視、繰り返しポーリングを開始しない。
- メール、チャット、Google Docs共有、公開、権限変更を行わない。
- 認証情報、Cookie、OAuth tokenを成果物へ書かない。
- 同梱テンプレートpackが `status: current` で、`template.md` のSHA-256がprofileと一致する場合だけ下書きを作る。
- 利用者へターミナル操作やコマンドのコピーを求めない。環境確認と許可後のコマンド実行はCodex自身が行う。

## 0. 環境を自分で確認する

最初に[環境事前診断](references/environment-preflight.md)を読み、Skillルートで次を1回だけ実行する。

```bash
zsh scripts/preflight.sh
```

- `node`、`npm`、Notta CLI、Notta認証、会社テンプレートをCodex自身が確認する。
- Notta CLIがなくnpmが使える場合は、公式パッケージを導入する許可を1回だけ取り、許可後はCodex自身が導入・確認する。
- OAuthが必要ならCodexが認証プロセスを開始し、ログイン済みChrome拡張で公式画面を利用者へ渡す。利用者はログイン・同意だけを行う。
- 診断は読取1回で終え、常駐処理や監視を残さない。

## 1. 対象と出力を固定する

開始前に次を確認する。

1. 会議名、日時、参加者のうち2つ以上、またはNotta record ID。
2. 録画基盤はZoom、文字起こし元はNottaとして別々に記録する。
3. 出力形式（Word / Google Docs / Markdown）と、正確な保存先。
4. 同梱された現在版テンプレートpackの完全性。

出力形式または保存先が未確認なら、下書きファイルを作らず、必要な1点だけ利用者へ確認して止める。現在の作業フォルダを暗黙の保存先にしない。

同日に同名候補が複数あり、1件へ絞れなければ `ambiguous` として止める。候補を推測で選ばない。

## 2. Notta本文を取得する

[Notta実機経路](references/notta-workflow.md) を読む。

環境診断が `notta_auth=ready` になった後、Codex自身が次を実行する。利用者へコマンド実行を依頼しない。

```bash
command -v notta
notta list --page 1 --page_size 100
notta status RECORD_ID
```

- `Transcribing` または `notta view` のエラー `110002` は処理中。失敗扱いにしない。
- ユーザーが「完成まで待って」と明示し、会議終了済みの場合だけ `notta status --wait RECORD_ID` を使える。
- 通常は処理中を報告して止め、常時監視を残さない。
- `Transcribed` を確認したら `notta view RECORD_ID` のJSONをローカルへ保存する。

保存例：

```bash
notta view RECORD_ID > "SOURCE.json"
python3 scripts/normalize_notta.py "SOURCE.json" --output "TRANSCRIPT.md"
```

`normalize_notta.py` はNotta公式CLIの実測形式に合わせ、`attr.start_time` を秒として扱う。別スキーマの数値時刻は推測しない。

## 3. 現在版テンプレートを使う

[テンプレート差し替え](references/template-replacement.md) を読む。

現在版は、2026年7月の出力見本と2026年8月27日の修正指示を反映し、個人情報を除いた `assets/templates/irodori-current/template.md` である。元の顧客入りGoogleドキュメントは公開packへ含めず、本人限定版の照合根拠としてだけ扱う。

ユーザーが過去のデモ・テンプレート・Google Docsの存在を示した場合、[過去テンプレート構造と再発見ルール](references/historical-template-shape.md)も読む。本人限定版の過去実例は、`references/client-private/manifest.yaml` と `checksums.sha256` があり、`preflight.sh` が `client_private_examples_integrity=verified` を返した場合だけ受入サンプルに使う。照合に失敗したら実例を読まずに停止する。

- `assets/templates/irodori-current/profile.yaml` の `status: current` と、同梱 `template.md` のSHA・確認日が揃っている場合だけ下書きに使う。
- `status: pending` またはSHA不一致なら、現在版packが壊れている／差し替え途中として止める。別の空テンプレートを利用者へ要求して先へ進めない。
- ユーザーが明示的に「デモで」と依頼した場合だけ `assets/templates/demo-only/` を使える。出力タイトルへ必ず `デモ` と入れる。
- 2024年11月版の旧テンプレートは使わない。

## 4. 下書きとmanifestを作る

文字起こし全文を省略せず読み、次を分けて記入する。

- 面談で確認できた事実
- 明示された意向・決定
- 次回アクション（担当・期限は根拠がある場合だけ）
- 未確認事項

商談フェーズを出力する時は、[OI・FF・PC・Nのチェック規則](references/phase-checks.md)を読む。`OI〜PC` のような範囲表記や、会話の雰囲気だけによる推定は使わない。

`【特記事項】` の末尾には、文字起こしから確認できた次回アクションを箇条書きで置く。担当・期限が明示されていないものは補わず、`要確認` とする。

数字、商品名、保険会社名、商談フェーズ、担当、期限、次回予定を推測しない。空欄を埋める必要がある場合は `要確認（文字起こしに明示なし）` とする。可能な限り話者と経過時刻を根拠として残す。

下書きの隣に `manifest.yaml` を作り、少なくとも次を記録する。

- 会議名、日時、参加者、Notta record ID
- `recording_provider: zoom`、`transcript_provider: notta`
- raw JSONと正規化Markdownのパス・SHA-256
- template ID・version・SHA-256・status
- 出力パス、`status: draft`
- 未確認事項と、実施していない外部操作

## 5. 保存後に検証する

[受入チェック](references/acceptance-checklist.md) を実行し、保存した実物を再読する。

完了報告は、生成物の絶対パス、対象record ID、使ったテンプレート版、残した要確認、外部共有していないことを先に伝える。

import fs from 'node:fs';
import path from 'node:path';
import * as W from './lib/whiteboard.mjs';
const {ink,group,label,arrow,page,envelope,calendar,laptop,clock,book,magnify,check,person,desk,speech,baseline,boardScene}=W;
const p=W.path;
const defaults=[['s1',0,16],['s2',16,20],['s3',36,16],['s4a',52,13],['s4b',65,13],['s4c',78,12],['s5',90,22],['s6',112,8]];
let timing=defaults.map(([id,start,duration])=>({id,start,duration}));
if(fs.existsSync('visual-timing.json'))timing=JSON.parse(fs.readFileSync('visual-timing.json','utf8'));
const T=id=>timing.find(s=>s.id===id);
const scenes=[];const motions=[];
function scene(id,body,opts){const t=T(id);scenes.push(boardScene(id,t.start,t.duration,body,{...opts,baseDuration:defaults.find(d=>d[0]===id)[2]}));}
function motion(scene,target,from,to,at,duration,ease='power1.inOut'){motions.push({scene,target,from,to,at,duration,ease});}
function pose(scene,target,d,at,duration=.6){motions.push({scene,target,to:{attr:{d}},at,duration,ease:'power1.inOut'});}

// 01: The same sheet remains continuous while responsibility passes to Dots.
{
let b=baseline('s1-ground',826,.6,1.5)
 +person('s1-human',325,668,{at:1.0,dur:2.6,pose:'give'})
 +person('s1-dots',1060,668,{at:3.8,dur:2.5,pose:'carry',ai:true})
 +page('s1-page',433,640,{at:3.1,dur:1.1,scale:1.05,lines:3})
 +label('s1-you','あなた',272,870,35,3.6,.8)
 +label('s1-dots-label','Dots',1002,870,39,6.0,.6)
 +speech('s1-ask',440,370,'これ、お願い。',{at:1.6,w:420,size:42,dur:1.2})
 +arrow('s1-transfer','M 555 622 Q 716 563 918 616','M 891 599 L 920 616 L 889 630',6.2,1)
 +desk('s1-desk',1588,690,8.0,1.6,280)
 +laptop('s1-work',1590,634,9.2,1.6,.78)
 +label('s1-after','相談のあとも、続きを進める',1150,400,37,11.3,1.8)
 +check('s1-check',1695,490,13.5,.6,.65);
scene('s1',b,{title:'返事の、その先へ。',caption:'続いていく仕事を、一緒に進める相棒。'});
motion('s1','#s1-page',{}, {x:648,y:40,rotation:-4},6.4,1.8);
pose('s1','#s1-human-rightarm path','M 4 -57 Q 39 -30 52 -46 Q 66 -65 59 -91',8.1,.7);
motion('s1','#s1-dots-actor',{}, {x:165},9.3,2.8);
motion('s1','#s1-page',{}, {x:813,y:40,rotation:2},9.3,2.8);
motion('s1','#s1-dots-label',{}, {x:165},9.3,2.8);
motion('s1','#s1-dots-head',{}, {rotation:5,svgOrigin:'0 -111'},12.5,.6);
}
// 02: Context arrives from different places and meets at one active helper.
{
let b=person('s2-dots',960,627,{at:.7,dur:2.3,pose:'carry',ai:true,scale:.98})
 +label('s2-dots-label','Dots',911,839,40,3,.6)
 +calendar('s2-calendar',368,417,2.4,1.6,1.05)
 +label('s2-cal-label','カレンダー',260,559,37,4,.9)
 +arrow('s2-a1','M 491 423 Q 663 406 851 539','M 826 513 L 852 539 L 819 535',4.4,1)
 +envelope('s2-mail',370,698,6,1.5,1.05)
 +label('s2-mail-label','メール',311,831,37,7.5,.8)
 +arrow('s2-a2','M 501 690 Q 666 710 849 644','M 821 639 L 850 644 L 829 666',8,1)
 +page('s2-file',1510,418,{at:9.4,dur:1.4,scale:1.18})
 +page('s2-file2',1485,445,{at:9.6,dur:1.6,scale:1.18})
 +label('s2-file-label','ファイル',1420,560,37,11.2,.8)
 +arrow('s2-a3','M 1369 423 Q 1190 431 1082 550','M 1105 524 L 1081 550 L 1114 541',11.6,1)
 +book('s2-memory',1500,699,13,1.8,.9)
 +label('s2-memory-label','会話の文脈',1405,843,37,14.8,1)
 +arrow('s2-a4','M 1355 690 Q 1203 709 1091 646','M 1112 672 L 1090 646 L 1123 648',15.3,1)
 +page('s2-context',995,617,{at:16.2,dur:1.3,scale:.73,lines:3,tick:true});
scene('s2',b,{title:'予定・メール・資料をつなぐ',caption:'何を見て、どこまで任せるかを伝える。'});
motion('s2','#s2-dots-head',{}, {rotation:-8,svgOrigin:'0 -111'},4.5,.6);
motion('s2','#s2-dots-head',{}, {rotation:8,svgOrigin:'0 -111'},11.6,.7);
pose('s2','#s2-dots-leftarm path','M -6 -58 Q -43 -28 -42 -5 Q -56 9 -62 -10',7.7,.8);
pose('s2','#s2-dots-leftarm path','M -6 -58 Q -39 -25 -28 3 Q 3 31 35 10',15.8,.8);
}
// 03: Branching work converges on a human decision and an inspectable record.
{
let b=baseline('s3-ground',830,.7,1.5)
 +person('s3-dots',330,666,{at:.9,dur:2.0,pose:'point',ai:true})
 +label('s3-dots-label','Dots',272,880,39,3,.7)
 +magnify('s3-search',453,436,1.9,1.7,.7)
 +arrow('s3-a1','M 510 582 Q 649 442 762 410','M 734 405 L 763 410 L 747 435',3.5,1)
 +page('s3-work',895,391,{at:4.1,dur:1.6,scale:.9,lines:4})
 +label('s3-work-label','Work',988,405,47,5.4,.7)
 +arrow('s3-a2','M 514 624 Q 657 679 764 705','M 738 684 L 765 705 L 730 712',5.7,1)
 +laptop('s3-codex',900,705,6.1,1.7,.76)
 +label('s3-codex-label','Codex',1020,724,44,7.8,.8)
 +ink('s3-code',900,705,p('M -44 -31 L -69 -10 L -43 9 M 47 -32 L 71 -10 L 47 8 M 14 -40 L -5 20','fine'),8.0,1.1)
 +arrow('s3-a3','M 1158 411 Q 1320 438 1458 536','M 1439 507 L 1459 536 L 1425 530',9,1.1)
 +arrow('s3-a4','M 1163 704 Q 1355 727 1459 656','M 1429 657 L 1460 656 L 1443 684',10,1.1)
 +person('s3-you',1580,666,{at:9.4,dur:2.2,pose:'point',flip:true})
 +label('s3-consult','ここは、どうする？',1332,382,35,11.6,1.3)
 +label('s3-activity','Activityで進み具合を確認',640,893,37,12.5,1.8)
 +check('s3-check',1686,478,13.8,.8,.65);
scene('s3',b,{title:'仕事を分けて、進める',caption:''});
motion('s3','#s3-dots-rightarm',{}, {rotation:-8,svgOrigin:'4 -57'},4,.8);
motion('s3','#s3-dots-rightarm',{}, {rotation:18,svgOrigin:'4 -57'},6.6,.9);
motion('s3','#s3-you-head',{}, {rotation:-6,svgOrigin:'0 -111'},12,.6);
}
// 04a: Author-reported example; preparation carried to an actual meeting.
{
let b=label('s4a-author','チャエンさんの投稿',127,258,31,.9,1.1,'class="muted"')
 +baseline('s4a-ground',828,.5,1.6)
 +clock('s4a-clock',1450,369,1.8,1.8,69)
 +label('s4a-thirty','商談の30分前',1545,382,37,3.5,1.1)
 +person('s4a-dots',437,668,{at:1.1,dur:2,pose:'carry',ai:true})
 +page('s4a-dossier',474,697,{at:3.2,dur:1.4,scale:1.14,lines:4})
 +label('s4a-company','相手の会社',283,418,35,3.7,1)
 +label('s4a-history','最近のやり取り',546,458,35,4.6,1.2)
 +desk('s4a-table',1360,675,5.6,1.3,280)
 +person('s4a-person1',1207,671,{at:6.0,dur:2.2,pose:'give',scale:.87})
 +person('s4a-person2',1557,671,{at:6.8,dur:2.2,pose:'give',scale:.87,flip:true})
 +check('s4a-prepared',1360,505,10.4,.7,.75);
scene('s4a',b,{title:'商談の前に、準備を済ませる',source:'SNS / 利用者の体験談',caption:'直前に、相手と話すための材料がそろう。'});
motion('s4a','#s4a-dots-actor',{}, {x:358},5.9,3.1);
motion('s4a','#s4a-dossier',{}, {x:358},5.9,3.1);
motion('s4a','#s4a-dossier',{}, {x:887,y:-70,rotation:5},9.2,1.2);
pose('s4a','#s4a-dots-rightarm path','M 4 -57 Q 41 -9 60 -17 Q 84 -23 105 -30',9.2,.8);
}
// 04b: A person walks and speaks while Dots sorts the work.
{
let b=label('s4b-author','Riley Brownさんの投稿',127,258,31,.8,1.4,'class="muted"')
 +baseline('s4b-ground',828,.5,1.4)
 +person('s4b-walker',343,669,{at:1.0,dur:2.3,pose:'phone'})
 +ink('s4b-phone',412,562,p('M -13 -29 Q -1 -31 13 -29 L 14 30 L -13 30 Z')+p('M -8 -22 L 8 -22 M -2 23 L 2 23','fine'),2.8,.7)
 +ink('s4b-earbuds',343,669,p('M -36 -111 L -33 -90 M 37 -111 L 33 -91','blue'),3,.5)
 +ink('s4b-sound',605,501,p('M -23 -19 Q -8 0 -23 19 M -8 -33 Q 21 0 -8 33 M 10 -48 Q 53 0 10 49','fine'),3.6,1)
 +arrow('s4b-a1','M 731 601 Q 807 568 866 601','M 839 583 L 868 601 L 837 613',5.0,.8)
 +person('s4b-dots',1040,669,{at:4.9,dur:2.2,pose:'point',ai:true})
 +envelope('s4b-mail1',1450,423,7.0,1.2,.73)
 +envelope('s4b-mail2',1434,608,8.4,1.2,.73)
 +label('s4b-mail-label','メール',1550,437,40,8.2,.8)
 +label('s4b-slack-label','Slackの仕事',1530,622,38,9.6,1)
 +check('s4b-sort1',1370,421,10,.6,.48)
 +check('s4b-sort2',1356,608,10.7,.6,.48)
 +arrow('s4b-a2','M 1170 576 Q 1280 491 1324 453','M 1295 458 L 1326 452 L 1314 478',7,.8);
scene('s4b',b,{title:'声で話しながら、仕事を整理する',source:'SNS / 利用者の体験談',caption:'スマホとイヤホンで、会話しながら。'});
motion('s4b','#s4b-walker-head',{}, {rotation:6,svgOrigin:'0 -111'},3.5,.7);


motion('s4b','#s4b-dots-rightarm',{}, {rotation:26,svgOrigin:'4 -57'},9.1,.75);
}
// 04c: A sleeping person and a testing assistant; report moves back by morning.
{
let b=label('s4c-author','toliさんの投稿',127,258,31,.8,1,'class="muted"')
 +baseline('s4c-ground',829,.5,1.5)
 +ink('s4c-moon',405,384,p('M 25 -62 C -49 -59 -76 34 -10 62 C 27 77 66 56 75 26 C 5 63 -43 -25 25 -62'),1,1.7)
 +ink('s4c-bed',400,730,p('M -180 -19 Q -23 -27 171 -20 L 171 51 L -180 51 Z M -180 -19 L -180 -69 M -180 51 L -180 94 M 171 51 L 171 92')+p('M -143 -34 Q -148 -79 -103 -76 Q -62 -76 -62 -35 Z')+p('M -56 -29 Q -15 -72 46 -65 Q 88 -58 132 -26')+p('M -128 -58 Q -121 -53 -113 -58 M -96 -58 Q -89 -53 -83 -58','fine'),2.2,2.0)
 +label('s4c-zzz','z z z',298,587,35,4.0,1)
 +person('s4c-dots',1040,670,{at:4.1,dur:2.1,pose:'point',ai:true})
 +desk('s4c-desk',1490,699,4.9,1.2,334)
 +laptop('s4c-app',1490,638,5.7,1.5,1.0)
 +ink('s4c-bug',1490,615,p('M -14 -15 Q -22 0 -11 19 Q 0 29 13 17 Q 24 -1 14 -15 Z M -12 -17 L -18 -29 M 12 -17 L 18 -29 M -16 -5 L -33 -12 M -19 6 L -34 7 M 19 -4 L 35 -12 M 20 8 L 37 12','fine'),7.1,1.2)
 +magnify('s4c-lens',1390,600,7.4,1.4,.85)
 +check('s4c-check',1580,619,9.3,.6,.5)
 +page('s4c-report',1260,656,{at:9.7,dur:.8,scale:.68,tick:true});
scene('s4c',b,{title:'夜のあいだに、アプリをテスト',source:'SNS / 利用者の体験談',caption:'これらは、それぞれの利用者の体験談です。'});
motion('s4c','#s4c-lens',{}, {x:105,y:10},8.4,1.0);
motion('s4c','#s4c-report',{}, {x:-670,y:30,rotation:-7},10.6,.6);
}
// 05: The request is written as a real note and handed across.
{
let b=baseline('s5-ground',854,.7,1.3)
 +person('s5-you',276,696,{at:1.1,dur:2.1,pose:'give',scale:.86})
 +person('s5-dots',1607,696,{at:2.1,dur:2.1,pose:'carry',ai:true,scale:.86})
 +ink('s5-note',958,550,p('M -452 -240 Q 0 -250 457 -242 L 466 254 Q 2 268 -460 255 Z')+p('M 429 -242 L 431 -208 L 458 -213','fine'),3.0,2.4)
 +label('s5-when','毎朝9時、日本時間で',572,420,48,5.5,2.0)
 +label('s5-what','今週の予定と未返信を整理して',570,516,44,8.1,2.5)
 +label('s5-three','重要な3件を教えて。',572,612,48,11.2,2)
 +ink('s5-underline',0,0,p('M 576 631 Q 813 640 1025 632','blue'),13.3,.8)
 +label('s5-ask','送信や予約の前には、確認してね。',570,722,40,14.5,3)
 +ink('s5-pinkline',0,0,p('M 574 743 Q 940 752 1339 746','pink'),17.4,.8)
 +check('s5-received',1722,480,19.2,.8,.7);
scene('s5',b,{title:'最初は、小さな担当をひとつ',source:'頼み方の例',caption:'目的 ＋ 時間 ＋ 相談してほしい線引き。'});
motion('s5','#s5-dots-head',{}, {rotation:8,svgOrigin:'0 -111'},18.8,.7);
pose('s5','#s5-you-rightarm path','M 4 -57 Q 33 -3 55 -12 Q 83 -17 106 -20',17.8,.8);
}
// 06: A last hand-off, space to choose, and an explicit dated condition.
{
let b=person('s6-you',668,635,{at:.2,dur:1.5,pose:'give',scale:.94})
 +person('s6-dots',1166,635,{at:1.2,dur:1.7,pose:'carry',ai:true,scale:.94})
 +page('s6-note',764,614,{at:2.5,dur:.8,scale:.66,lines:2})
 +arrow('s6-a1','M 845 612 Q 936 578 1048 613','M 1022 595 L 1050 613 L 1019 625',3.2,.7)
 +label('s6-conditions','使える機能は、プランや接続先によって変わります。',960,854,35,3.9,1.7,'text-anchor="middle"')
 +label('s6-date','2026年10月3日時点',960,924,31,5.8,1.0,'text-anchor="middle" class="muted"');
scene('s6',b,{title:'あなたなら、最初に何を任せる？',source:'2026.10.03',final:true});
motion('s6','#s6-note',{}, {x:435,y:8,rotation:-5},4.2,1.4);
motion('s6','#s6-dots-head',{}, {rotation:6,svgOrigin:'0 -111'},6.2,.6);
}

// Two alternating planted-leg poses make carrying an actual walk, then settle.
function walk(scene,id,at,duration,steps=6){
 const step=duration/steps;
 for(let i=0;i<steps;i++){
  const forward=i%2===0;
  pose(scene,`#${id}-leg-left`,forward?'M -2 56 Q 22 96 36 154 L 53 157':'M -2 56 Q -26 95 -43 155 L -60 157',at+i*step,step);
  pose(scene,`#${id}-leg-right`,forward?'M -2 56 Q -18 107 -34 154 L -20 157':'M -2 56 Q 23 100 41 156 L 57 157',at+i*step,step);
 }
 pose(scene,`#${id}-leg-left`,'M -2 56 Q -24 94 -45 155 L -60 157',at+duration,.3);
 pose(scene,`#${id}-leg-right`,'M -2 56 Q 23 100 41 156 L 57 157',at+duration,.3);
}
walk('s1','s1-dots',9.3,2.8,6);
walk('s4a','s4a-dots',5.9,3.1,6);

const end=Math.max(...timing.map(t=>t.start+t.duration));
const baseDur=Object.fromEntries(defaults.map(([id,s,d])=>[id,d]));
let audio='';
if(fs.existsSync('audio-config.json')){const a=JSON.parse(fs.readFileSync('audio-config.json','utf8')); audio=`<audio id="dots-narration" src="${a.src}" data-start="${a.start||0}" data-duration="${a.duration}" data-track-index="2" data-volume="1"></audio>`;}
const html=`<!doctype html><html lang="ja"><head><meta charset="UTF-8"><meta name="viewport" content="width=1920,height=1080"><title>Dotsって何ができるの？</title><script src="assets/gsap.min.js"></script><style>
@font-face{font-family:'Yomogi';src:url('assets/Yomogi-Regular.ttf') format('truetype');font-weight:400;font-display:block}*{box-sizing:border-box}html,body{margin:0;background:#fff}#dots-whiteboard{position:relative;width:100%;height:100%;overflow:hidden;background:#fff}.clip{position:absolute;inset:0}.clip svg{width:100%;height:100%;display:block}text{font-family:'Yomogi';font-weight:400;fill:#252a2e;letter-spacing:.015em}.muted{fill:#626c71}.ink{fill:none;stroke:#252a2e;stroke-width:3.1;stroke-linecap:round;stroke-linejoin:round}.ink.fine{stroke-width:2.3}.ink.eyes{stroke-width:4.8}.ink.blue{stroke:#4f8899;stroke-width:3.3}.ink.pink{stroke:#b76d87;stroke-width:4}.eraser{pointer-events:none}
</style></head><body><main id="dots-whiteboard" data-composition-id="dots-whiteboard" data-start="0" data-duration="${end}" data-width="1920" data-height="1080" data-fps="30">${scenes.join('\n')}${audio}</main><script>
const visualTiming=${JSON.stringify(timing)},baseDur=${JSON.stringify(baseDur)},motionData=${JSON.stringify(motions)};
const tl=gsap.timeline({paused:true});
for(const scene of visualTiming){
 const root=document.getElementById(scene.id);const ratio=scene.duration/baseDur[scene.id];const t=v=>scene.start+v*ratio;
 for(const group of root.querySelectorAll('[data-ink-start]')){
  const paths=[...group.querySelectorAll('path.ink')];const lens=paths.map(p=>p.getTotalLength());const sum=lens.reduce((a,b)=>a+b,0);const d=+group.dataset.inkDuration;let cursor=0;
  paths.forEach((path,i)=>{const len=lens[i];path.style.strokeDasharray=len+' '+len;path.style.strokeDashoffset=String(len);path.style.opacity='0';const span=d*(.38/paths.length+.62*len/sum);tl.set(path,{opacity:1},t(+group.dataset.inkStart+cursor));tl.fromTo(path,{strokeDashoffset:len},{strokeDashoffset:0,duration:span*ratio,ease:'none'},t(+group.dataset.inkStart+cursor));cursor+=span;});
 }
 for(const text of root.querySelectorAll('[data-write]')){
  const spans=[...text.querySelectorAll('tspan')];spans.forEach(s=>s.style.opacity='0');const d=+text.dataset.writeDuration;tl.to(spans,{opacity:1,duration:.075*ratio,stagger:Math.max(.012,(d-.075)/Math.max(1,spans.length-1))*ratio,ease:'none'},t(+text.dataset.write));
 }
 const eraser=root.querySelector('.eraser');if(eraser)tl.fromTo(eraser,{x:0},{x:1930,duration:.55,ease:'power1.inOut'},scene.start+scene.duration-.6);
}
for(const m of motionData){const s=visualTiming.find(s=>s.id===m.scene);const k=s.duration/baseDur[m.scene];const to={...m.to,duration:m.duration*k,ease:m.ease,immediateRender:false};if(m.from)tl.fromTo(m.target,m.from,to,s.start+m.at*k);else tl.to(m.target,to,s.start+m.at*k);}
window.__timelines=window.__timelines||{};window.__timelines['dots-whiteboard']=tl;
</script></body></html>`;
fs.writeFileSync('index.html',html);
fs.writeFileSync('timings.json',JSON.stringify({duration:end,scenes:timing,authoredBaseDurations:baseDur},null,2));
console.log(`Built ${timing.length} scenes, ${end.toFixed(3)} seconds; ${audio?'narration attached':'visual preview (voice pending)'}.`);
